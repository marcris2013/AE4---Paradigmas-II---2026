# Criterios académicos y reglas – Integrante 3 (Lisandro Jardin)

> La AE4 no define completamente estos criterios. Lo que sigue es una **propuesta**
> que el grupo debe confirmar (ver sección 4). Si se cambia algo, hay que
> actualizar `Integrante3.hs` / `integrante3.pl` y los datos compartidos.

## 1. Criterios definidos

| Criterio | Definición | Dónde se usa |
|---|---|---|
| Materia aprobada | Situación final Regular o Promocionado (Libre y "en curso" no cuentan). Es el mismo criterio de `esAprobada` del Integrante 2. | Prolog: `aprobada/2` |
| Inscripción finalizada | Tiene situación final cargada (en Haskell `Just _`, en Prolog existe `situacion_final/3`). | Haskell punto 5 |
| Porcentaje de promocionados | `promocionadas / finalizadas * 100` por materia. Las inscripciones en curso no entran en el cálculo. | Haskell punto 5 |
| Límite de inasistencias para promocionar | **2** inasistencias como máximo. Es menor al umbral de alerta al coordinador (3) y coincide con el criterio de "alumno destacado" del Integrante 2. | Prolog consulta 5 |
| Puede promocionar | Inscripción **en curso** + inasistencias ≤ 2 + correlativas aprobadas. | Prolog consulta 5 |
| Correlatividad | `correlativa(Materia, Requisito)`: para cursar `Materia` hay que tener aprobado `Requisito`. | Prolog consulta 6 |
| Puede cursar | Matriculado en la carrera de la materia + correlativas aprobadas + todavía no aprobó esa materia. | Prolog consulta 6 |

## 2. Correlatividades propuestas

Las materias de primer año no tienen correlativas.

| Materia | Requiere |
|---|---|
| programacion_ii | programacion_i |
| bases_de_datos | programacion_ii |
| ingenieria_de_software | bases_de_datos |
| redes | programacion_ii |
| contabilidad_ii | contabilidad_i |
| impuestos | contabilidad_ii |

## 3. Funcionalidades implementadas

### Haskell – punto 5 (`Haskell/Integrante3.hs`)
- `porcentajePromocionados idMateria registros` → `Maybe Double`.
- `porcentajesPorMateria registros` → lista de `(idMateria, porcentaje)`.
- `materiaConMayorPromocion registros` → `Maybe (idMateria, porcentaje)`; si hay empate queda la primera materia de la lista.
- Requisitos técnicos del módulo:
  - **Orden superior:** `map`, `filter` y listas por comprensión.
  - **Composición:** `esPromocionada = (== Just Promocionado) . situacionFinal` y `materiaConMayorPromocion = mayorPorcentaje . porcentajesPorMateria`.
  - **Recursividad:** `contarRecursivo` (Integrante 1), `quitarRepetidos` y `mayorPorcentaje` (Integrante 3).

### Prolog – consulta 5 (`Prolog/integrante3.pl`)
- `alumnos_que_pueden_promocionar(IdMateria, Legajo, Nombre, Apellido)`: en curso, hasta 2 inasistencias y correlativas aprobadas.
- `cumple_requisitos_promocion(Legajo, IdMateria)`: lo mismo pero sin mirar el estado, sirve para comprobar a quienes ya promocionaron.

### Prolog – consulta 6 (`Prolog/integrante3.pl`)
- `correlativas_faltantes(Legajo, IdMateria, IdRequisito)`.
- `puede_cursar(Legajo, IdMateria)`.
- `correlativas_totales(IdMateria, IdRequisito)`: directas e indirectas (recursiva).

## 4. Decisiones a confirmar con el grupo

1. ¿Límite de 2 inasistencias para promocionar?
2. ¿Correlatividades de la sección 2?
3. ¿"Aprobada" = Regular o Promocionado?
4. Con los datos de prueba actuales **ningún alumno puede promocionar**: el único en curso es Pedro Ruiz (4 inasistencias). Para que la consulta 5 muestre un resultado, el grupo podría agregar un alumno en curso con pocas inasistencias, en Haskell y Prolog a la vez.

## 5. Pruebas y resultados esperados (datos compartidos actuales)

Haskell (`cd Haskell && runghc MainIntegrante3.hs`):

| Materia | % promocionados |
|---|---|
| programacion_i | 50.0 (1 de 2 finalizadas; Pedro está en curso) |
| matematica_i_sistemas | 0.0 |
| matematica_i_contable | 100.0 |
| contabilidad_i | 0.0 |
| materia_sin_inscriptos | Nothing |

Materia con mayor porcentaje: Matemática I de Analista Contable (`matematica_i_contable`, 100%).

Prolog (`cd Prolog && swipl universidad.pl integrante2.pl integrante3.pl`):

```prolog
?- cumple_requisitos_promocion(L, M).      % 1001-programacion_i, 1001-matematica_i_sistemas, 1004-matematica_i_contable, 1005-contabilidad_i
?- alumnos_que_pueden_promocionar(M, L, N, A).   % false (nadie en curso cumple)
?- correlativas_totales(ingenieria_de_software, R). % bases_de_datos, programacion_ii, programacion_i
?- correlativas_faltantes(1002, programacion_ii, R). % programacion_i
?- puede_cursar(1001, M).                  % programacion_ii
```
